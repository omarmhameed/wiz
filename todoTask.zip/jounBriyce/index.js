let noteValue=document.getElementById("noteValue");
let note=document.getElementById("note");
let dd=document.getElementById("dd");
let btn=document.getElementById("btn");



let content=document.getElementById("content")
let closeIcon;
let another;
btn.addEventListener("click",function(){
 
    if(note.value && dd.value){

        let pNote=document.createElement("p");
        pNote.textContent=note.value;
       // noteValue.appendChild(pNote);
        let dateValue=document.createElement("p");
        dateValue.textContent=dd.value;


        let valueOb=[{"title":pNote,"date":dateValue }]

        dateValue.style.position="absolute"
        dateValue.style.bottom="15px"
        dateValue.style.left="5px"
       // noteValue.appendChild(dateValue);
      //  noteValue.className="noteValue"
        
    //content.appendChild(noteValue)
        note.value="";

valueOb.map((e)=>{


    
    let another=document.createElement("div")
    another.appendChild(e.title);
    another.appendChild(e.date);
    let closeIcon=document.createElement("span");
    closeIcon.className="material-symbols-outlined"
    closeIcon.style.right="33px"
    closeIcon.style.top="15px"
    closeIcon.style.position="absolute"
        another.style.position="relative";

        closeIcon.textContent="close"
        closeIcon.style.display="none"
       
        another.appendChild(closeIcon)

    content.appendChild(another)
    another.className="noteValue"

another.addEventListener("mouseover",()=>{

    closeIcon.style.display="block"

})

 another.addEventListener("mouseleave",()=>{

    closeIcon.style.display="none"

})
       
        closeIcon.addEventListener("click",()=>{

            another.remove()
         })})
         localStorage.setItem("another",JSON.parse(valueOb))
         content.innerHTML=localStorage.getItem("another")
        }
        else alert("the note or the date is empty")
        note.value=""
        dd.value=""
}) 

